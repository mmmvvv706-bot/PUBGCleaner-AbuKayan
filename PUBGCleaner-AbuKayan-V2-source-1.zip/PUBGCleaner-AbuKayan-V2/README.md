# PUBG Cleaner – Abu Kayan (V2)

Arabic Android Java project. **Source only, not a built APK.**

## New in V2

- Uses the Shizuku 13.1.5 API and a UserService to scan authorized PUBG Mobile Saved/Paks folders as ADB shell/root, when the user starts and grants Shizuku permission.
- Looks for **exactly `puffer_temp`** (file or folder) in Paks or nested subfolders up to 6 levels deep; supported package names: `com.tencent.ig`, `com.pubg.krmobile`, `com.vng.pubgmobile`, `com.rekoo.pubgm`.
- Displays each candidate's exact path and asks again for confirmation before deleting that candidate; does not delete other Paks or game files.
- Follows neither symlink folders nor symlink targets. A one-time scan is needed before a delete request.
- Original V1 functions remain: device stats, manually selected document deletion via SAF, settings shortcut, game launcher, Telegram support **@OmarVIP3**.

## Important user warnings

- `puffer_temp` can be part of the game's download/resource pipeline and **is not verified safe to delete**. PUBG may recreate it or redownload resources; gameplay can break. This is **not** an FPS guarantee.
- Android 11+ limits ordinary apps from `Android/data`/`Android/obb`; **Shizuku** with appropriate ADB/root permissions is required. Shizuku access is not guaranteed on all OEM ROMs.
- **Close PUBG completely before attempting deletion.** The app never edits APKs, `.pak` files, logs, configs, security settings, or the game's anti-cheat system.
- The app has not been built or tested on a real device in this environment.

## Building an APK on GitHub

1. Upload **contents of this project folder** (not the outer directory) to the root of a GitHub repository.
2. Go to **Actions → Build PUBG Cleaner APK → Run workflow**.
3. Download artifact `PUBGCleaner-AbuKayan-V2-debug` once the build succeeds.

Uses Gradle 8.10.2, Android Gradle Plugin 8.7.3, SDK 35, Java 17, Shizuku API+Provider 13.1.5, minSdk 26.

Shizuku official setup: https://shizuku.rikka.app/
