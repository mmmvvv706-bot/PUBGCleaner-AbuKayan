package com.abukayan.pubgcleaner;

interface IPaksCleaner {
    String[] scanTargets();
    String deleteTarget(String absolutePath);
    void destroy() = 16777114;
}
