package com.abukayan.pubgcleaner;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.RemoteException;
import rikka.shizuku.Shizuku;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_CHOOSE_FILE = 1001;
    private static final int SHIZUKU_PERMISSION = 4811;
    private IPaksCleaner remote;
    private TextView targetStatus;
    private boolean scanWaiting = false;
    private boolean serviceBinding = false;
    private final Shizuku.OnRequestPermissionResultListener permissionListener =
            (code, result) -> {
                if (code == SHIZUKU_PERMISSION) runOnUiThread(() -> {
                    if (result == PackageManager.PERMISSION_GRANTED) connectForScan();
                    else setTargetStatus("❌ لم يتم السماح بوصول Shizuku.");
                });
            };
    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            remote = IPaksCleaner.Stub.asInterface(binder);
            serviceBinding = false;
            if (scanWaiting) { scanWaiting = false; scanViaService(); }
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            remote = null;
            serviceBinding = false;
            setTargetStatus("⚠️ انقطع الاتصال بـ Shizuku. أعد تشغيله عند الحاجة.");
        }
    };
    private static final int BG = Color.rgb(10, 18, 35);
    private static final int CARD = Color.rgb(22, 36, 59);
    private static final int BLUE = Color.rgb(39, 157, 229);
    private static final int GOLD = Color.rgb(251, 196, 87);
    private static final int WHITE = Color.rgb(242, 246, 255);
    private static final int MUTED = Color.rgb(177, 192, 213);
    private LinearLayout main;
    private TextView stats;
    private TextView result;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        Shizuku.addRequestPermissionResultListener(permissionListener);
        refreshStats();
    }

    private int dp(int value) { return (int) (getResources().getDisplayMetrics().density * value + 0.5f); }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView label(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.RIGHT);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void addText(LinearLayout parent, String value, int sp, int color, boolean bold, int top) {
        TextView text = label(value, sp, color, bold);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(top);
        parent.addView(text, p);
    }

    private LinearLayout card(String title, String description) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.setBackground(bg(CARD, 18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(16);
        main.addView(box, p);
        addText(box, title, 20, GOLD, true, 0);
        addText(box, description, 14, MUTED, false, 9);
        return box;
    }

    private void action(LinearLayout box, String title, int color, View.OnClickListener onClick) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(title);
        b.setTextColor(WHITE);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(bg(color, 14));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(55));
        p.topMargin = dp(14);
        box.addView(b, p);
        b.setOnClickListener(onClick);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(dp(18), dp(30), dp(18), dp(40));
        main.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(main);
        setContentView(scroll);
        addText(main, "🎮 PUBG CLEANER", 28, GOLD, true, 0);
        addText(main, "أبو كيان | الإصدار V2.0", 15, MUTED, false, 6);

        LinearLayout storage = card("📊 معلومات الجهاز", "معلومات حقيقية عن مساحة الهاتف والذاكرة؛ لا ندّعي زيادة FPS بشكل مضمون.");
        stats = label("جارٍ قراءة مساحة الجهاز...", 15, WHITE, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(12);
        storage.addView(stats, sp);
        action(storage, "🔄 تحديث المعلومات", BLUE, v -> refreshStats());

        LinearLayout clean = card("🧹 تنظيف ملف تختاره بنفسك", "يتيح أندرويد حذف الملفات التي تسمح لك نافذة اختيار الملفات بالوصول إليها فقط. لن يتم حذف أي ملف دون موافقتك الصريحة.");
        action(clean, "📁 اختيار ملف ومراجعته للحذف", BLUE, v -> chooseFile());
        result = label("لم يتم اختيار أي ملف.", 14, MUTED, false);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(12);
        clean.addView(result, rp);
        addText(clean, "⚠️ لن يتمكن التطبيق العادي من فتح ملفات PUBG الخاصة في Android/data أو Android/obb أو ذاكرة اللعبة الداخلية، بسبب حماية أندرويد.", 13, GOLD, false, 14);

        LinearLayout custom = card("🎯 فحص puffer_temp داخل ببجي",
                "يفحص المجلد Saved/Paks والمجلدات الفرعية في نسخ PUBG المعروفة، ويعرض أي ملف أو مجلد اسمه puffer_temp فقط. الحذف اختياري بعد التأكيد. يتطلب Shizuku فعّالًا؛ وقد تعيد اللعبة إنشاء الملف أو تنزيل بيانات جديدة.");
        action(custom, "🔎 فحص مجلدات ببجي باستخدام Shizuku", BLUE, v -> connectForScan());
        targetStatus = label("لم يبدأ الفحص. تأكد من إغلاق اللعبة أولًا.", 14, MUTED, false);
        LinearLayout.LayoutParams tps = new LinearLayout.LayoutParams(-1, -2);
        tps.topMargin = dp(12);
        custom.addView(targetStatus, tps);
        action(custom, "⚙️ تعليمات تشغيل Shizuku", Color.rgb(64, 85, 121), v ->
                new AlertDialog.Builder(this).setTitle("Shizuku بدون روت")
                        .setMessage("1- ثبّت Shizuku من المصدر الرسمي.\n2- شغّله بواسطة Wireless Debugging في إعدادات المطور.\n3- اسمح لتطبيق PUBG Cleaner بالوصول عند ظهور طلب التصريح.\n4- أغلق ببجي، ثم اضغط فحص.\n\nملاحظة: بعض الهواتف قد تمنع الوصول حتى مع Shizuku.")
                        .setNegativeButton("إغلاق", null)
                        .setPositiveButton("موقع Shizuku", (d, w) -> {
                            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/"))); }
                            catch (Exception ignored) { }
                        }).show());
        addText(custom, "⚠️ puffer_temp قد يكون من ملفات تنزيل موارد اللعبة؛ لا يمكن ضمان أنه ملف زائد. الحذف قد يسبب إعادة تنزيل موارد أو مشاكل في التشغيل ولا يضمن زيادة FPS.", 13, GOLD, false, 14);

        LinearLayout performance = card("🚀 أدوات تحسين الأداء", "تحسين الاستخدام المتاح للهاتف دون تعديل ملفات اللعبة أو التحايل على حمايتها.");
        action(performance, "⚙️ فتح إعدادات مساحة التخزين", BLUE, v -> openStorageSettings());
        action(performance, "🎮 تشغيل PUBG إن كانت مثبتة", Color.rgb(51, 129, 103), v -> openPubg());
        addText(performance, "نصائح: اترك مساحة خالية كافية، خفّض إعدادات الرسوميات عند الحاجة، وأغلق التطبيقات الثقيلة بالطريقة العادية.", 14, MUTED, false, 12);

        LinearLayout about = card("👨‍💻 المطور والدعم الفني", "المطور: أبو كيان\nتليجرام: @OmarVIP3");
        action(about, "✈️ تواصل مع المطور على تليجرام", BLUE, v -> openTelegram());
        addText(main, "هذا تطبيق مستقل وغير تابع لشركة PUBG Mobile. لا نحذف ملفات اللعبة الأساسية ولا نضمن تغيير FPS.", 12, MUTED, false, 22);
    }

    private void refreshStats() {
        try {
            StatFs stat = new StatFs(Environment.getDataDirectory().getPath());
            long free = stat.getAvailableBytes();
            long total = stat.getTotalBytes();
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo memory = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(memory);
            stats.setText("💾 السعة الإجمالية: " + formatBytes(total) + "\n" +
                    "✅ المساحة المتاحة: " + formatBytes(free) + "\n" +
                    "🧠 ذاكرة RAM المتاحة: " + formatBytes(memory.availMem));
        } catch (Exception e) {
            stats.setText("تعذر قراءة معلومات التخزين على هذا الجهاز.");
        }
    }

    private String formatBytes(long bytes) {
        return String.format(Locale.US, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }

    private void chooseFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
            startActivityForResult(i, REQUEST_CHOOSE_FILE);
        } catch (ActivityNotFoundException e) {
            result.setText("لا يوجد مدير ملفات متوافق على الهاتف.");
        }
    }

    @Override protected void onActivityResult(int req, int code, Intent data) {
        super.onActivityResult(req, code, data);
        if (req != REQUEST_CHOOSE_FILE || code != RESULT_OK || data == null || data.getData() == null) return;
        Uri file = data.getData();
        String fileName = getFileName(file);
        if (!DocumentsContract.isDocumentUri(this, file)) {
            result.setText("الملف المختار لا يدعم الحذف الآمن عبر مدير ملفات النظام.");
            return;
        }
        if (!supportsDelete(file)) {
            result.setText("الملف «" + fileName + "» غير قابل للحذف من خلال الصلاحية المتاحة.");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("تأكيد حذف الملف")
                .setMessage("الملف: " + fileName + "\n\nالحذف قد يكون نهائيًا، وقد تتسبب إزالة ملفات اللعبة في تلفها أو إعادة تنزيل مواردها. هل أنت متأكد؟")
                .setNegativeButton("إلغاء", (d, w) -> result.setText("تم إلغاء الحذف."))
                .setPositiveButton("حذف الملف", (d, w) -> deleteSelected(file, fileName))
                .show();
    }

    private boolean supportsDelete(Uri uri) {
        try (Cursor c = getContentResolver().query(uri,
                new String[]{DocumentsContract.Document.COLUMN_FLAGS}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int flags = c.getInt(0);
                return (flags & DocumentsContract.Document.FLAG_SUPPORTS_DELETE) != 0;
            }
        } catch (Exception ignored) { }
        return false;
    }

    private String getFileName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                String name = c.getString(0);
                if (!TextUtils.isEmpty(name)) return name;
            }
        } catch (Exception ignored) { }
        return "ملف محدد";
    }

    private void deleteSelected(Uri uri, String name) {
        try {
            boolean ok = DocumentsContract.deleteDocument(getContentResolver(), uri);
            result.setText(ok ? "✅ تم حذف الملف: " + name : "❌ لم يسمح مدير الملفات بحذف هذا الملف.");
        } catch (Exception e) {
            result.setText("❌ تعذر حذف الملف: صلاحية الحذف غير متاحة أو الملف محمي.");
        }
        refreshStats();
    }

    private void openStorageSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS));
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح إعدادات التخزين", Toast.LENGTH_LONG).show();
        }
    }

    private void openPubg() {
        String[] packages = {"com.tencent.ig", "com.pubg.krmobile", "com.vng.pubgmobile", "com.rekoo.pubgm"};
        for (String pkg : packages) {
            try {
                Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
                if (launch != null) {
                    startActivity(launch);
                    return;
                }
            } catch (Exception ignored) { }
        }
        new AlertDialog.Builder(this).setMessage("لم يتم العثور على نسخة PUBG مدعومة على هذا الهاتف.")
                .setPositiveButton("حسنًا", null).show();
    }

    private void openTelegram() {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/OmarVIP3"));
        try {
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح رابط تليجرام", Toast.LENGTH_SHORT).show();
        }
    }
    private void setTargetStatus(String message) {
        runOnUiThread(() -> { if (targetStatus != null) targetStatus.setText(message); });
    }

    private void connectForScan() {
        scanWaiting = true;
        try {
            if (!Shizuku.pingBinder()) {
                scanWaiting = false;
                setTargetStatus("❌ Shizuku غير مشغّل. افتح تعليمات التشغيل أدناه.");
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                if (Shizuku.shouldShowRequestPermissionRationale()) {
                    scanWaiting = false;
                    setTargetStatus("❌ تصريح Shizuku مرفوض. عدّل صلاحية التطبيق من Shizuku.");
                } else {
                    setTargetStatus("🔐 يرجى الموافقة على تصريح Shizuku...");
                    Shizuku.requestPermission(SHIZUKU_PERMISSION);
                }
                return;
            }
            if (remote != null && remote.asBinder().isBinderAlive()) {
                scanWaiting = false;
                scanViaService();
                return;
            }
            if (!serviceBinding) {
                serviceBinding = true;
                setTargetStatus("🔗 جارٍ الاتصال بخدمة Shizuku...");
                Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(
                        new ComponentName(this, PaksCleanerService.class))
                        .daemon(false).processNameSuffix("paksCleaner").version(1);
                Shizuku.bindUserService(args, serviceConnection);
            }
        } catch (Exception | LinkageError e) {
            serviceBinding = false;
            scanWaiting = false;
            setTargetStatus("❌ تعذر الوصول إلى Shizuku على هذا الجهاز.");
        }
    }

    private void scanViaService() {
        IPaksCleaner service = remote;
        if (service == null) return;
        setTargetStatus("🔎 جاري البحث عن puffer_temp داخل Saved/Paks...");
        new Thread(() -> {
            try {
                String[] matches = service.scanTargets();
                runOnUiThread(() -> showMatches(matches));
            } catch (RemoteException | RuntimeException e) {
                setTargetStatus("❌ تعذّر الفحص. قد تكون المجلدات محمية أو Shizuku غير متصل.");
            }
        }, "paks-scan").start();
    }

    private void showMatches(String[] matches) {
        if (matches == null || matches.length == 0) {
            setTargetStatus("لم يعثر الفحص على puffer_temp، أو تعذر الوصول إلى مجلدات بعض نسخ ببجي.");
            return;
        }
        setTargetStatus("✅ تم العثور على " + matches.length + " ملف/مجلد باسم puffer_temp. اضغط على المسار لمراجعته.");
        String[] options = new String[matches.length];
        for (int i = 0; i < matches.length; i++) {
            options[i] = matches[i].replace("/storage/emulated/0/Android/data/", "Android/data/");
        }
        new AlertDialog.Builder(this)
                .setTitle("نتائج فحص puffer_temp")
                .setItems(options, (dialog, choice) -> confirmDelete(matches[choice]))
                .setNegativeButton("إغلاق دون حذف", null).show();
    }

    private void confirmDelete(String path) {
        new AlertDialog.Builder(this).setTitle("⚠️ تأكيد حذف puffer_temp")
                .setMessage("المسار:\n" + path +
                        "\n\nسيتم حذف الملف أو المجلد المسمى puffer_temp بما فيه من محتويات، وقد تحتاج اللعبة لإعادة تنزيل بيانات. أغلق اللعبة قبل المتابعة.\n\nهل تؤكد الحذف؟")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("نعم، احذف هذا فقط", (dialog, which) -> deletePuffer(path))
                .show();
    }

    private void deletePuffer(String path) {
        IPaksCleaner service = remote;
        if (service == null) { setTargetStatus("❌ أعد الاتصال بـ Shizuku."); return; }
        setTargetStatus("⏳ جارٍ حذف puffer_temp المحدد فقط...");
        new Thread(() -> {
            try {
                String result = service.deleteTarget(path);
                switch (result) {
                    case "DELETED": setTargetStatus("✅ تم حذف: " + path + "\nقد تعيد اللعبة إنشاء الملف."); break;
                    case "NOT_FOUND": setTargetStatus("لم يعد الملف موجودًا في المسار المحدد."); break;
                    case "DENIED": setTargetStatus("❌ رفض الحذف: المسار غير معتمد أو ليس نتيجة الفحص."); break;
                    default: setTargetStatus("❌ لم يكتمل الحذف. قد يكون الملف محميًا.");
                }
            } catch (RemoteException | RuntimeException e) {
                setTargetStatus("❌ تعذر إتمام الحذف بواسطة Shizuku.");
            }
        }, "paks-delete").start();
    }

    @Override protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        super.onDestroy();
    }

}
