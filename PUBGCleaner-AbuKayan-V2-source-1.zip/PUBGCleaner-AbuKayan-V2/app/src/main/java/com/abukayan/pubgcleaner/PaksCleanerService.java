package com.abukayan.pubgcleaner;

import android.os.RemoteException;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Only runs as a Shizuku UserService (shell/root identity).
 * Never executes caller-provided shell commands.
 * Only scans Saved/Paks within the four known PUBG Mobile packages.
 * Only deletes exact entries named puffer_temp after a preceding scan.
 */
public final class PaksCleanerService extends IPaksCleaner.Stub {
    private static final String[] PACKAGES = {
            "com.tencent.ig", "com.pubg.krmobile",
            "com.vng.pubgmobile", "com.rekoo.pubgm"
    };
    private static final String TAIL = "/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks";
    private static final String TARGET = "puffer_temp";
    private static final int MAX_DEPTH = 6;
    private static final int MAX_VISITS = 10000;
    private final Set<String> lastScan = new HashSet<>();

    public PaksCleanerService() { }

    @Override public synchronized String[] scanTargets() throws RemoteException {
        lastScan.clear();
        int[] budget = {MAX_VISITS};
        for (String pkg : PACKAGES) {
            File base = new File("/storage/emulated/0/Android/data/" + pkg + TAIL);
            if (!base.isDirectory() || !base.canRead()) continue;
            find(base, base, 0, budget);
        }
        List<String> entries = new ArrayList<>(lastScan);
        Collections.sort(entries);
        return entries.toArray(new String[0]);
    }

    private void find(File base, File current, int depth, int[] budget) {
        if (depth > MAX_DEPTH || budget[0] <= 0 ||
                !isUnderAllowedBase(base, current)) return;
        File[] children = current.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (--budget[0] < 0) return;
            if (Files.isSymbolicLink(child.toPath())) continue;
            if (TARGET.equals(child.getName()) && isUnderAllowedBase(base, child)) {
                lastScan.add(child.getAbsolutePath());
                continue; // do not descend into a candidate that may be deleted
            }
            if (child.isDirectory()) find(base, child, depth + 1, budget);
        }
    }

    private boolean isUnderAllowedBase(File base, File child) {
        try {
            String b = base.getCanonicalPath();
            String c = child.getCanonicalPath();
            if (!c.startsWith(b + File.separator) && !c.equals(b)) return false;
            // The base itself must be the expected Paks directory for an allowed package.
            for (String pkg : PACKAGES) {
                File expected = new File("/storage/emulated/0/Android/data/" + pkg + TAIL);
                if (b.equals(expected.getCanonicalPath())) return true;
            }
        } catch (IOException | SecurityException ignored) { }
        return false;
    }

    @Override public synchronized String deleteTarget(String absolutePath) throws RemoteException {
        if (absolutePath == null || !lastScan.contains(absolutePath)) return "DENIED";
        File f = new File(absolutePath);
        if (!TARGET.equals(f.getName())) return "DENIED";
        boolean accepted = false;
        for (String pkg : PACKAGES) {
            File base = new File("/storage/emulated/0/Android/data/" + pkg + TAIL);
            if (isUnderAllowedBase(base, f) && !isSymlinkInTree(base, f)) {
                accepted = true;
                break;
            }
        }
        if (!accepted) return "DENIED";
        if (!f.exists()) { lastScan.remove(absolutePath); return "NOT_FOUND"; }
        boolean ok = deleteRecursively(f);
        if (ok) lastScan.remove(absolutePath);
        return ok ? "DELETED" : "FAILED";
    }

    private boolean isSymlinkInTree(File base, File target) {
        File cur = target;
        while (cur != null && !cur.equals(base)) {
            if (Files.isSymbolicLink(cur.toPath())) return true;
            cur = cur.getParentFile();
        }
        return cur == null;
    }

    private boolean deleteRecursively(File target) {
        if (Files.isSymbolicLink(target.toPath())) return false;
        if (target.isDirectory()) {
            File[] children = target.listFiles();
            if (children == null) return false;
            for (File child : children) {
                if (Files.isSymbolicLink(child.toPath())) {
                    if (!child.delete()) return false;
                } else if (!deleteRecursively(child)) return false;
            }
        }
        return target.delete();
    }

    @Override public void destroy() throws RemoteException { System.exit(0); }
}
