plugins {
    id("com.android.application")
}

android {
    namespace = "com.abukayan.pubgcleaner"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.abukayan.pubgcleaner"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }

    buildFeatures {
        aidl = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}


dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
